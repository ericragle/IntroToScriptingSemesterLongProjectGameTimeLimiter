import subprocess  # for launching subprocesses
import platform  # for detecting os if needed
import os  # for system-level commands like exit
import sys  # for accessing interpreter and arguments
import time  # for sleep delays
import signal  # for sending termination signals
import shutil  # for checking for bash
import threading  # for running game monitor in parallel

# absolute path to the directory where launch.py is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# script file names 
FLASK_SERVER = os.path.join("Scripts", "game_time_server.py") 
PYTHON_CLIENT = os.path.join("Scripts", "game_time_client.py")
TIME_NOTIFIER = os.path.join("Scripts", "game_time_notifier.bat")
TIME_LIMITER = os.path.join("Scripts", "game_time_limiter.sh")

# game process to monitor
GAME_NAME = "tf_win64.exe"  # name of the game process to track

# store launched subprocesses
processes = []  # list to keep track of launched scripts

# function to launch a script and add to list
def launch_script(command, shell=False):
    try:
        proc = subprocess.Popen(command, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE)  # capture output and error
        processes.append(proc)  # add to process list
        return proc  # return process handle
    except Exception as e:
        print(f"failed to launch {command}: {e}")  # print error if launch fails
        return None  # return none on failure

# function to capture and print subprocess output
def capture_output(proc):
    stdout, stderr = proc.communicate()  # capture stdout and stderr
    if stdout:
        print(stdout.decode())  # print stdout
    if stderr:
        print(stderr.decode())  # print stderr


# function to terminate all running scripts
def terminate_all():
    print("\nterminating all scripts...")  # print termination message
    for p in processes:
        try:
            p.terminate()  # try to terminate process
        except Exception:
            pass  # ignore if termination fails
    for p in processes:
        try:
            p.wait(timeout=5)  # wait for process to end
        except Exception:
            pass  # ignore timeout errors
    print("cleanup complete. exiting launcher.")  # print cleanup done

# function to get path to bash
def get_bash_path():
    bash = shutil.which("bash")  # check for bash in path
    if not bash:
        print("bash not found (git bash is required for bash components).")  # print missing bash message
        sys.exit(1)  # exit if bash is missing
    return bash  # return bash path

# function to check if game is running
def is_game_running():
    try:
        output = subprocess.check_output(['tasklist'], shell=True, text=True)  # get tasklist
        return GAME_NAME.lower() in output.lower()  # check if game is in tasklist
    except Exception:
        return False  # return false on error

# function to monitor game and shut down when it closes
def monitor_game():
    print(f"monitoring game process: {GAME_NAME}")  # print monitoring start
    while True:
        if not is_game_running():  # if game not running
            print(f"game {GAME_NAME} has closed.")  # print game closed
            terminate_all()  # terminate all scripts
            os._exit(0)  # forcefully exit launcher
        time.sleep(3)  # wait before checking again

# main function
def main():
    try:
        print("Thank you for using Game Time Limiter!\n") # welcome message
        print("Launching game-time limiter components...\n")  # print launch start

        # start flask server
        print("Starting flask server...")  # print start server
        launch_script([sys.executable, FLASK_SERVER])  # launch server

        time.sleep(1)  # give server time to start

        # start time notifier
        print("Starting Time Notifier...")  # print notifier start
        launch_script(["cmd.exe", "/c", TIME_NOTIFIER])  # launch batch script

        # start bash limiter
        print("Starting Time Limiter...")  # print limiter start
        bash_path = get_bash_path()  # get bash path
        launch_script([bash_path, TIME_LIMITER])  # launch bash script

        # start python client
        print("Starting Client...")  # print client start
        launch_script([sys.executable, PYTHON_CLIENT])  # launch client

        print("\nAll components launched. \nMonitoring game...\n")  # print all started

        # start monitor thread
        monitor_thread = threading.Thread(target=monitor_game, daemon=True)  # create monitor thread
        monitor_thread.start()  # start monitor

        # keep script alive
        while True:
            time.sleep(1)  # sleep to keep script running

    except KeyboardInterrupt:
        terminate_all()  # terminate on ctrl+c
        print("Shutdown complete. Get to work!")  # print shutdown done

# entry point
if __name__ == "__main__":
    main()  # call main
