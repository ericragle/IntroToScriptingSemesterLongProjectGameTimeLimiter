import requests  # import library to make http requests
import time  # import time library for delays

SERVER_URL = "http://localhost:5000"  # server ip (localhost)
CLIENT_ID = "client_1"  # client identifier

def get_remaining_time():  # function to get remaining time from server
    try:
        response = requests.get(f"{SERVER_URL}/get_time/{CLIENT_ID}")  # send get request to server
        if response.status_code == 200:  # check if request was successful
            return response.json()['remaining_time']  # return remaining time from response
    except Exception as e:
        print(f"Error getting time: {e}")  # print error if request fails
    return None  # return none if error

def send_warning():  # function to send warning to server
    try:
        response = requests.post(f"{SERVER_URL}/send_warning/{CLIENT_ID}")  # send post request to server
        if response.status_code == 200 and 'warning' in response.json():  # check if response is ok and has warning
            print(response.json()['warning'])  # print warning message
    except Exception as e:
        print(f"Warning error: {e}")  # print error if request fails

if __name__ == "__main__":  # main program starts here
    while True:  # loop forever
        remaining_time = get_remaining_time()  # get remaining time from server
        if remaining_time is None:  # if failed to get time, stop
            break
        if remaining_time <= 0:  # if time is up, stop
            print("Game time is up.")
            break
        print(f"Remaining time: {remaining_time} seconds")  # print remaining time
        if remaining_time <= 20:  # if time is low, send warning
            send_warning()
        time.sleep(1)  # wait 1 second before next check
