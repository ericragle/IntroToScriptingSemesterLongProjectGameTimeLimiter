from flask import Flask, jsonify, request  # import necessary Flask components
import logging  # import logging for logging messages
import json  # import json for working with JSON data
import os  # import os for file and path operations

# configuration
LOG_FILE = "server.log"  # set log file name
CLIENT_FILE = "client_times.json"  # set client data file name
TIME_LIMIT = 45  # set maximum time limit in seconds
TIME_WARNING = 20  # set time warning threshold in seconds

logging.basicConfig(filename=LOG_FILE, level=logging.INFO)  # configure logging to write to log file
app = Flask(__name__)  # create Flask app instance

# load client times
def load_client_times():  # define function to load client times from file
    if os.path.exists(CLIENT_FILE):  # check if client times file exists
        with open(CLIENT_FILE, 'r') as f:  # open file in read mode
            return json.load(f)  # load and return JSON data from file
    return {}  # return empty dictionary if file doesn't exist

# save client times to file
def save_client_times(times):  # define function to save client times to file
    with open(CLIENT_FILE, 'w') as f:  # open file in write mode
        json.dump(times, f)  # write times data to file in JSON format

client_times = load_client_times()  # load client times into memory

@app.route('/get_time/<client_id>', methods=['GET'])  # define route to get remaining time for a client
def get_time(client_id):  # define function to get remaining time for a specific client
    if client_id not in client_times:  # check if client_id exists in client times
        return jsonify({"error": "Client not found"}), 404  # return error if client not found
    return jsonify({"remaining_time": client_times[client_id]})  # return remaining time for the client

@app.route('/set_time/<client_id>', methods=['POST'])  # define route to set remaining time for a client
def set_time(client_id):  # define function to set time for a specific client
    data = request.json  # get JSON data from the request
    time_value = data.get('remaining_time')  # extract 'remaining_time' value from the data
    if time_value is None or not isinstance(time_value, int) or time_value > TIME_LIMIT or time_value < 0:  # check if time value is valid
        return jsonify({"error": "Invalid time value"}), 400  # return error if time value is invalid
    client_times[client_id] = time_value  # set the client's remaining time
    save_client_times(client_times)  # save updated client times to file
    logging.info(f"{client_id} time updated to {time_value} seconds.")  # log the time update
    return jsonify({"message": "Time updated"}), 200  # return success message

@app.route('/send_warning/<client_id>', methods=['POST'])  # define route to send warning to a client
def send_warning(client_id):  # define function to send warning if time is about to expire
    if client_id not in client_times:  # check if client_id exists in client times
        return jsonify({"error": "Client not found"}), 404  # return error if client not found
    if client_times[client_id] <= TIME_WARNING:  # check if client's remaining time is less than or equal to the warning threshold
        return jsonify({"warning": "Time is almost up!"}), 200  # return warning message if time is running low
    return jsonify({"message": "No warning necessary"}), 200  # return success message if no warning is needed

if __name__ == '__main__':  # check if script is run directly
    app.run(debug=False, host='0.0.0.0', port=5000)  # run Flask app with specified settings (no debug, all IPs, port 5000)
