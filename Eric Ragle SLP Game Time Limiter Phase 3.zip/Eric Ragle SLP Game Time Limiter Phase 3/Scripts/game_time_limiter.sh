#!/bin/bash

# configuration
GAME_NAME="tf_win64" # game process name without .exe
TIME_LIMIT=45 # total allowed game time in seconds
TIME_WARNING=20 # time before timeout to show a warning
LOG_FILE="/tmp/game_time_limiter.log" # full path to log file

# function to log a message with timestamp
log_message() {
    echo "$(date): $1" >> "$LOG_FILE" # write the message with timestamp to log file
}

# function to check if the game process is running
is_game_running() {
    pgrep -x "$GAME_NAME" > /dev/null # check if game process is running using pgrep
}

# function to terminate the game process
kill_game() {
    log_message "terminating $GAME_NAME due to time limit." # log that game is being terminated
    pkill -x "$GAME_NAME" # kill the game process using pkill
}

log_message "started game time limiter for $GAME_NAME." # log the start of the game time limiter

start_time=$(date +%s) # record the current time when the script starts

while true; do
    if ! is_game_running; then # check if game is no longer running
        log_message "$GAME_NAME is not running." # log that the game is not running
        exit 0 # exit the script if game is no longer running
    fi

    current_time=$(date +%s) # get the current time in seconds since epoch
    elapsed_time=$((current_time - start_time)) # calculate elapsed time

    if [ "$elapsed_time" -ge "$TIME_LIMIT" ]; then # if elapsed time exceeds the time limit
        kill_game # kill the game process
        exit 0 # exit the script after killing the game
    elif [ "$elapsed_time" -eq "$((TIME_LIMIT - TIME_WARNING))" ]; then # check if it's time to show the warning
        log_message "warning: $GAME_NAME will close in $TIME_WARNING seconds." # log the warning
    fi

    sleep 1 # pause the script for 1 second before repeating the loop
done

