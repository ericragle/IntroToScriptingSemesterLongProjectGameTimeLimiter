USER GUIDE
------------------------------------------------

* THIS PROGRAM REQUIRES GIT BASH, PYTHON, A TEXT EDITOR (Notepad, Notepad++, etc.), AND PYTHON FLASK TO WORK

1. Open the 'game_time_limiter.sh' file in the 'Scripts' folder in a text editor.
2. Open Task Manager.
3. Locate the process name of the game you would like to limit the time of.
4. Visit line 4 of the Shell script. Replace 'tf_win64' with the desired process name. DO NOT INCLUDE THE FILE EXTENSION.
5. Visit lines 5 and 6. Change the warning and limit time to whatever you desire.
6. Save and exit.
7. Open your game/application you want to limit.
8. Open Command Prompt/Git Bash/etc.
9. Use cd to navigate to the folder 'launch.py' is in.
10. Run 'launch.py' after your game/application has been opened.
11. Enjoy your productivity.
