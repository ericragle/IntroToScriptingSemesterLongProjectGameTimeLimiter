USER GUIDE
------------------------------------------------

* THIS PROGRAM REQUIRES GIT BASH, PYTHON, AND PYTHON FLASK TO WORK. NOTEPAD++ IS RECOMMENDED, BUT IS IT POSSIBLE TO USE THIS APPLICATION WITHOUT IT.

1. Open the 'game_time_limiter.sh' file in a text editor, such as Notepad++.
2. Open Task Manager.
3. Locate the process name of the game you would like to limit the time of.
4. Visit line 4 of the Shell script. Replace 'tf_win64' with the desired process name. DO NOT INCLUDE THE FILE EXTENSION.
5. Visit line 7 of the Shell script. 'tf_win64' with the desired process name. DO NOT INCLUDE THE FILE EXTENSION.
6. Save the script.
7. Open Command Prompt as an administrator. 
8. Navigate to the directory the Game Time Limiter is in using 'cd' and pasting the directory.
9. Run the 'game_time_limiter.sh' by typing 'bash game_time_limiter.sh'.
9. Open the 'game_time_limiter.log' to receive notification of warnings and when the game is terminated.
