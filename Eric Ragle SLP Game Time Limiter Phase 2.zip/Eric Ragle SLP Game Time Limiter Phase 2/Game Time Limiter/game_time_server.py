from flask import Flask, jsonify, request  # imports necessary modules from flask
import logging  # imports logging module
import time  # imports time module
import json  # imports json module
import os  # imports os module

# configuration
LOG_FILE = "server.log"  # sets log file name
CLIENT_FILE = "client_times.json"  # sets client times file name

logging.basicConfig(filename=LOG_FILE, level=logging.INFO)  # configures logging to file

app = Flask(__name__)  # creates Flask application instance

# load client times function
def load_client_times():
    if os.path.exists(CLIENT_FILE):  # checks if client file exists
        with open(CLIENT_FILE, 'r') as f:  # opens client file in read mode
            return json.load(f)  # loads and returns client times from file
    return {}  # returns empty dictionary if file doesn't exist

# save client times function
def save_client_times(client_times):
    with open(CLIENT_FILE, 'w') as f:  # opens client file in write mode
        json.dump(client_times, f)  # saves client times to file

client_times = load_client_times()  # loads client times at the start

# route to get remaining time for a client
@app.route('/get_time/<client_id>', methods=['GET'])
def get_time(client_id):
    if client_id not in client_times:  # checks if client ID exists in client times
        return jsonify({"error": "Client not found"}), 404  # returns error if client not found

    remaining_time = client_times[client_id]  # gets remaining time for the client
    return jsonify({"remaining_time": remaining_time})  # returns remaining time in JSON format

# route to set or update remaining time for a client
@app.route('/set_time/<client_id>', methods=['POST'])
def set_time(client_id):
    data = request.json  # gets JSON data from the request
    remaining_time = data.get('remaining_time')  # gets remaining time from the data

    if not remaining_time or remaining_time > TIME_LIMIT:  # checks if time is invalid
        return jsonify({"error": "Invalid time value"}), 400  # returns error if time is invalid

    client_times[client_id] = remaining_time  # updates client time
    save_client_times(client_times)  # saves updated client times
    logging.info(f"Client {client_id} time set to {remaining_time} seconds.")  # logs time update
    return jsonify({"message": "Time updated successfully"}), 200  # returns success message

# route to send time warning to client
@app.route('/send_warning/<client_id>', methods=['POST'])
def send_warning(client_id):
    if client_id not in client_times:  # checks if client ID exists
        return jsonify({"error": "Client not found"}), 404  # returns error if client not found

    if client_times[client_id] <= TIME_WARNING:  # checks if client's time is below warning threshold
        return jsonify({"warning": "Time is almost up!"}), 200  # sends warning if time is low
    return jsonify({"message": "No warning necessary"}), 200  # returns no warning message if not necessary

if __name__ == '__main__':  # checks if script is being run directly
    app.run(debug=True, host='0.0.0.0', port=5000)  # starts Flask app on port 5000