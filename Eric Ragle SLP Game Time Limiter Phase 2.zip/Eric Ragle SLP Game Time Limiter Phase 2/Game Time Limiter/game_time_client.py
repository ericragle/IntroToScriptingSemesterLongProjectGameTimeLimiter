import requests  # imports requests module for HTTP requests
import time  # imports time module for time-related functions

# configuration
SERVER_URL = "http://<server_ip>:5000"  # sets server URL
CLIENT_ID = "client_1"  # sets unique client identifier

# get remaining time function
def get_remaining_time():
    response = requests.get(f"{SERVER_URL}/get_time/{CLIENT_ID}")  # sends GET request to server
    if response.status_code == 200:  # checks if response status is OK
        return response.json()['remaining_time']  # returns remaining time from server response
    else:
        print("Error: Unable to get remaining time.")  # prints error message if failed
        return None  # returns None if there is an error

# update remaining time function
def update_remaining_time(time_left):
    response = requests.post(f"{SERVER_URL}/set_time/{CLIENT_ID}", json={"remaining_time": time_left})  # sends POST request to update time
    if response.status_code == 200:  # checks if response status is OK
        print("Time updated successfully.")  # prints success message if time is updated
    else:
        print("Error: Unable to update time.")  # prints error message if failed

# send warning function
def send_warning():
    response = requests.post(f"{SERVER_URL}/send_warning/{CLIENT_ID}")  # sends POST request for warning
    if response.status_code == 200:  # checks if response status is OK
        print(response.json()['warning'])  # prints the warning message from server response

# main loop
if __name__ == "__main__":  # checks if script is run directly
    while True:  # starts an infinite loop
        remaining_time = get_remaining_time()  # gets the remaining time
        if remaining_time is None:  # checks if remaining time is None (error occurred)
            break  # breaks the loop if error occurs

        if remaining_time <= 0:  # checks if remaining time is 0 or less
            print("Game time is up!")  # prints message if time is up
            break  # breaks the loop if time is up

        print(f"Remaining time: {remaining_time} seconds")  # prints the remaining time
        
        # check if warning should be sent
        if remaining_time <= 300:  # checks if remaining time is less than or equal to 5 minutes
            send_warning()  # sends warning

        time.sleep(60)  # waits for 1 minute before checking again
