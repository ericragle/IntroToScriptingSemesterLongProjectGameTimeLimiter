#!/bin/bash

# configuration
GAME_NAME="tf_win64"  # sets game process name
TIME_LIMIT=45  # sets time limit (seconds)
TIME_WARNING=20  # sets time warning (seconds)
LOG_FILE="C:/Users/Eric/Downloads/Eric Ragle SLP Game Time Limiter Phase 2/game_time_limiter.log"  # sets log file path (hardcoded for now)

# log message function
log_message() {
    echo "$(date): $1" >> "$LOG_FILE"  # logs current date and message to log file
}

# check if game is running function
is_game_running() {
    powershell -Command "Get-Process | Where-Object { \$_.Name -eq 'tf_win64' }"  # checks if game process is running
}

# kill game process function
kill_game() {
    log_message "Attempting to terminate game $GAME_NAME."  # logs attempt to terminate game
    powershell -Command "Stop-Process -Name '$GAME_NAME' -Force"  # forces termination of game process
    log_message "Game $GAME_NAME terminated due to time limit."  # logs game termination
}

# start tracking time
log_message "Game Time Limiter started for $GAME_NAME."  # logs start of time limiter

# track elapsed time
start_time=$(date +%s)  # stores start time

while true; do
    if ! is_game_running; then
        log_message "Game $GAME_NAME is not running."  # logs if game is not running
        exit 0  # exits if game is not running
    fi # ends if statement

    current_time=$(date +%s)  # gets current time
    elapsed_time=$((current_time - start_time))  # calculates elapsed time

    if [ "$elapsed_time" -ge "$TIME_LIMIT" ]; then
        kill_game  # kills game if time limit is reached
        exit 0  # exits after killing game
    elif [ "$elapsed_time" -ge "$((TIME_LIMIT - TIME_WARNING))" ]; then
        log_message "Warning: Time is almost up for $GAME_NAME. ($elapsed_time/$TIME_LIMIT seconds)"  # logs warning when time is close
    fi # ends if statement

    sleep 1  # waits for 1 second before checking again
done # finish
